typedef struct profile_s {
    int id;
    int socket;
} profile;

typedef struct chat_s {
    int id;
    profile first;
    profile second
} chat;
